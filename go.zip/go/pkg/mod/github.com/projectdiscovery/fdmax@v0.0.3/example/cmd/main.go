package main

import (
	"fmt"

	_ "github.com/projectdiscovery/fdmax/autofdmax"
)

func main() {
	fmt.Println("test")
}
