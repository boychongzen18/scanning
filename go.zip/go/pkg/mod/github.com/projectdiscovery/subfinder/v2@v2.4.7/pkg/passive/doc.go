// Package passive provides capability for doing passive subdomain
// enumeration on targets.
package passive
