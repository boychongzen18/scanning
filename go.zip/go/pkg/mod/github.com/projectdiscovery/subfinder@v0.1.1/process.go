//
// process.go : Contains main package drivers and stuff
// Written By : @codingo
//		@ice3man
//
// Distributed Under MIT License
// Copyrights (C) 2018 Ice3man
//

package main
